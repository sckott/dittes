The contents in this subdirectory are used for building web assets.

To build, install the requirements (below), then go to this directory and run:

```
make
```

## Requirements

### UglifyJS

UglifyJS is a module for node.js which minifies Javascript files. It should be
installed with the following command (run from this directory):

```
npm install uglify-js
```

This will install the UglifyJS into `./node_modules/`.
